class WelcomeController < ApplicationController
end
